<?php

namespace App\Controller;

use App\Entity\Category;
use App\Repository\CategoryRepository;
use App\Repository\ProductRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Core\Security;
use Symfony\Component\Security\Http\Authentication\AuthenticationUtils;

class HomeController extends AbstractController
{
    #[Route('/', name: 'app_home')]
    public function index(CategoryRepository $categoryRepository): Response
    {
        $categories = $categoryRepository->findAll();
        return $this->render('home/index.html.twig', [
            'categories' => $categories,
            'controller_name' => 'HomeController',
        ]);
    }


    #[Route('/products/{id}', name: 'app_products')]
    public function products(Category $category, ProductRepository $productRepository): Response
    {
        $products = $productRepository->findBy(['category' => $category]);
        return $this->render('home/products.html.twig', [
            'products' => $products,
            'controller_name' => 'HomeController',
        ]);
    }
    #[Route('/login', name: 'login')]
    public function login(AuthenticationUtils $authenticationUtils): Response
    {
        $error = $authenticationUtils->getLastAuthenticationError();
        $lastUsername = $authenticationUtils->getLastUsername();
        return $this->render('home/login.html.twig', [
            'controller_name' => 'LoginController',
            'last_username' => $lastUsername,
            'error' => $error,
            ]);
    }

    #[Route('/logout', name: 'logout')]
    public function logout(): Response
    {
        // controller can be blank: it will never be called!
        throw new \Exception('Don\'t forget to activate logout in security.yaml');
    }

    #[Route('/redirect', name: 'redirect')]
    public function redirectAction(Security $security) {
      if ($security->isGranted('ROLE_ADMIN')) {
          return $this->redirectToRoute('app_admin');
      }
      if ($security->isGranted('ROLE_KLANT')) {
          return $this->redirectToRoute('app_klant');
      }
        return $this->render('app_home');
    }
}
